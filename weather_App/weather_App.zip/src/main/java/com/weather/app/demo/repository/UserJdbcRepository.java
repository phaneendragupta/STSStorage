//package com.weather.app.demo.repository;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.dao.EmptyResultDataAccessException;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Repository;
//
//import com.weather.app.demo.entity.User;
//
//@Repository
//public class UserJdbcRepository implements UserRepository {
// 
//	@Autowired
//	private final JdbcTemplate jdbcTemplate;
//
//	public UserJdbcRepository(JdbcTemplate jdbcTemplate) {
//
//		this.jdbcTemplate = jdbcTemplate;
//	}
//
//	// add user
//	@Override
//	public User save(User user) {
//		String insertQry = "INSERT INTO users(user_name,user_email,password) VALUES (?,?,?)";
//		jdbcTemplate.update(insertQry, user.getUser_name(), user.getUser_email(), user.getPassword());
//		return user;
//	}
//	
//	// get user
//    @SuppressWarnings("deprecation")
//	@Override
//	public User findByname(String username) {
//		String selectQry = "SELECT * From users WHERE username =?";
//		
//	try {
//		return jdbcTemplate.queryForObject(selectQry,new Object[] {username}, (resultSet,rowNum) ->{
//			User user =new User();
//		user.setUser_id(resultSet.getInt("user_id"));
//		user.setUser_name(resultSet.getString("user_name"));
//		user.setUser_email(resultSet.getString("user_email"));
//		user.setPassword(resultSet.getString("password"));
//		
//		//for mapping user properties
//		return user;
//		
//		});
//		
//		} catch (EmptyResultDataAccessException e) {
//			
//			return null;
//
//			}
//		
//		
//	}
//	//find all users
//
//	@Override
//	public List<User> findAll() {
//		String selectQry= "SELECT * FROM users";
//		return jdbcTemplate.query(selectQry, (resultSet, rowNum)->{
//			
//	         User user = new User();
//			
//	     	user.setUser_id(resultSet.getInt("user_id"));
//			user.setUser_name(resultSet.getString("user_name"));
//			user.setUser_email(resultSet.getString("user_email"));
//			user.setPassword(resultSet.getString("password"));
//			
//			return user;
//		
//			
//		});
//		
//	
//	
//	}
//
//}
