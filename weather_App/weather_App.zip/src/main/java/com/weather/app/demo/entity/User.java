package com.weather.app.demo.entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Entity
@Table(name="users")
@AllArgsConstructor
@NoArgsConstructor
public class User{
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	
	private String userName;
	private String userEmail;
	
	private String password;
	
	//private String role;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(
			name="user_roles",
	        joinColumns = @JoinColumn(
	                 name ="user_id",referencedColumnName="userId"),
	        inverseJoinColumns =@JoinColumn(
	            	 name = "role_id",referencedColumnName="roleId")
			)
	private List<Role> roles ;
//	
//	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinTable(
//			name="user_roles",
//	        joinColumns = @JoinColumn(
//	                 name ="user_id", referencedColumnName = "id"),
//	        inverseJoinColumns =@JoinColumn(
//	            	 name = "role_id", referencedColumnName = "id"
//	            		 ))
//	

	public User(String userName, String userEmail, String password, List<Role> roles) {
		super();
		this.userName = userName;
		this.userEmail = userEmail;
		this.password = password;
		this.roles = roles;
	}


	
}




