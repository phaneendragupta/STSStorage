package com.weather.app.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.weather.app.demo.dto.UserRegistrationDto;
import com.weather.app.demo.entity.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
	User findUserByname(String username);
	User findByEmail(String email);
    List<User> findAllUsers();
	User save (User user);
	Optional<User> getUserById(int id);
	User registerUser(User user);
	User updateUser(int id, User user);
	String deleteUser(int id);

	
}